<?php echo $__env->make('admin.dashboard.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('admin.dashboard.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- ============================================================== -->
            <!-- Start right Content here -->
            <!-- ============================================================== -->
            <div class="main-content">

                <div class="page-content">
                    <div class="container-fluid">

                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                                    <h4 class="mb-sm-0 font-size-18">Laporan Siswa PKL</h4>

                                    <div class="page-title-right">
                                        <ol class="breadcrumb m-0">
                                            <li class="breadcrumb-item"><a href="javascript: void(0);">Laporans</a></li>
                                            <li class="breadcrumb-item active">Laporan</li>
                                        </ol>
                                    </div>

                                </div>
                            </div>

                            <div class="row">
                                <div class="col-12">
                                    <div class="card">
                                        <div class="card-body">
                                            
                                            <h4 class="card-title mb-0 mt-2">Laporan Siswa PKL</h4>
                                            <!-- App Search-->
                                            <div class="app-search float-end d-none d-lg-block mt-2 mb-2">
                                                <form action="/laporan-siswa">
                                                    <div class="input-group position-relative">
                                                        <input type="text" class="form-control" placeholder="Search.." name="search" value="<?php echo e(request('search')); ?>">
                                                        <button class="btn btn-primary" type="submit">Search</button>
                                                    </div>
                                                </form>
                                            </div>
    
                                            <table id="datatable" class="table table-bordered dt-responsive nowrap w-100" style="border-collapse: collapse; border: 1px solid #cccccc;">
                                                <thead>
                                                <tr style="background: steelblue; color: white; text-align:center;">
                                                    <th>No</th>
                                                    <th>Nama</th>
                                                    <th>Nama Sekolah</th>
                                                    <th>Kelas</th>
                                                    <th>Jurusan</th>
                                                    <th>Nama Pembimbing</th>
                                                    <th>No.Telp</th>
                                                    <th>Tanggal Bergabung</th>
                                                    <th>Kemampuan</th>
                                                    <th>Status</th>
                                                </tr>
                                                </thead>
            
                                                <tbody class="text-center">
                                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($loop->iteration); ?></td>
                                                    <td><?php echo e($user->nama); ?></td>
                                                    <td><?php echo e($user->nama_sekolah); ?></td>
                                                    <td><?php echo e($user->kelas); ?></td>
                                                    <td><?php echo e($user->jurusan); ?></td>
                                                    <td><?php echo e($user->nama_pembimbing); ?></td>
                                                    <td><?php echo e($user->nomor_telepon); ?></td>
                                                    <td><?php echo e($user->tanggal_bergabung); ?></td>
                                                    <td><?php echo e($user->department->posisi); ?></td>
                                                    <td>
                                                        <?php if($user->status == '0'): ?>
                                                        <a href="" class="bg-warning text-light bg-status">Pending</a>
                                                        <?php elseif($user->status == 'Ditolak'): ?>
                                                        <a href="" class="bg-danger text-white bg-status">Ditolak</a>
                                                        <?php else: ?>
                                                        <a href="" class="bg-success text-light bg-status">Diterima</a>
                                                        <?php endif; ?>
                                                    </td>
                                                </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div> <!-- end col -->
                            </div> <!-- end row -->
                            
                        </div>
                            <!-- </div> -->
                        <!-- end page title -->

                        <footer class="footer">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-sm-6">
                                        PT.Era Solution
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="text-sm-end d-none d-sm-block">
                                            Design & Develop by SMKN 9 BEKASI
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </footer>
            </div>
            <!-- end main content-->

        </div>
        <!-- END layout-wrapper -->

<?php echo $__env->make('admin.dashboard.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\laragon\www\pendaftaranPKLext\resources\views/admin/laporanStatusPKL/index.blade.php ENDPATH**/ ?>