<?php echo $__env->make('koorPKL.dashboard.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('koorPKL.dashboard.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <!-- ============================================================== -->
            <!-- Start right Content here -->
            <!-- ============================================================== -->
            <div class="main-content">
                

                <div class="row justify-content-center">
                    <div class="col-lg-7 col-md-8 col-sm-10">
                    <div class="card o-hidden border-dark shadow-lg">
                        <div class="card-body p-0 mt-5">
                            <!-- Nested Row within Card Body -->
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="p-5">
                                        <div class="text-center mb-2">
                                            <h1 class="h4 mb-5 pt-4 text-xl font-semibold">Add New Data Agenda</h1>
                                        </div>
                                        <form action="/dataAgenda" method="POST" class="agenda" enctype="multipart/form-data">
                                            <?php echo csrf_field(); ?>
                                            <div class="mt-1">
                                                <label for="user_id" class="form-label"> Name</label>
                                                <select class="form-select" name="user_id">
                                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if(old('user_id') == $user->id): ?>
                                                            <option value="<?php echo e($user->id); ?>" selected><?php echo e($user->nama); ?></option>
                                                        <?php else: ?>
                                                            <option value="<?php echo e($user->id); ?>"><?php echo e($user->nama); ?></option>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                            <div class="mt-1">
                                                <label for="kelas" class="form-label"> Kelas</label>
                                                <select class="form-select" name="kelas">
                                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if(old('kelas') == $user->id): ?>
                                                            <option value="<?php echo e($user->id); ?>" selected><?php echo e($user->kelas); ?></option>
                                                        <?php else: ?>
                                                            <option value="<?php echo e($user->id); ?>"><?php echo e($user->kelas); ?></option>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                            <div class="mt-1">
                                                <label for="jurusan" class="form-label"> Jurusan</label>
                                                <select class="form-select" name="jurusan">
                                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if(old('jurusan') == $user->id): ?>
                                                            <option value="<?php echo e($user->id); ?>" selected><?php echo e($user->jurusan); ?></option>
                                                        <?php else: ?>
                                                            <option value="<?php echo e($user->id); ?>"><?php echo e($user->jurusan); ?></option>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                            <div class="mt-1">
                                                <label for="kategori_id" class="form-label"> Kategori</label>
                                                <select class="form-select" name="kategori_id">
                                                    <?php $__currentLoopData = $kategori_agendas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if(old('kategori_id') == $kategori->id): ?>
                                                            <option value="<?php echo e($kategori->id); ?>" selected><?php echo e($kategori->kategori); ?></option>
                                                        <?php else: ?>
                                                            <option value="<?php echo e($kategori->id); ?>"><?php echo e($kategori->kategori); ?></option>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                            <div class="mt-1">
                                                <label for="tanggal" class="form-label">Hari/Tanggal</label>
                                                <input value="<?php echo e(old('tanggal')); ?>" type="date" class="form-control <?php $__errorArgs = ['tanggal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="tanggal" id="tanggal" autofocus required>
                                                <?php $__errorArgs = ['tanggal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="invalid-feedback">
                                                        <?php echo e($message); ?>

                                                    </div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                                <button class="btn btn-primary w-100 py-2 mt-3" type="submit">Create Data Agenda</button>
                                        </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- end main content-->


<?php echo $__env->make('admin.dashboard.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php /**PATH C:\laragon\www\pendaftaranPKLext\resources\views/koorPKL/agenda/dataAgenda/create.blade.php ENDPATH**/ ?>