
            <!-- ============================================================== -->
            <!-- Start right Content here -->
            <!-- ============================================================== -->
            <div class="main-content">

                <div class="page-content">
                    <div class="container-fluid">

                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                                    <h4 class="mb-sm-0 font-size-18">Dashboard</h4>

                                    <div class="page-title-right">
                                        <ol class="breadcrumb m-0">
                                            <li class="breadcrumb-item"><a href="javascript: void(0);">Dashboards</a></li>
                                            <li class="breadcrumb-item active">Dashboard</li>
                                        </ol>
                                    </div>

                                </div>
                            </div>
                            
                                <div class="row">
                                <div class="col-xl-4">
                                    <div class="card overflow-hidden">
                                        <div class="bg-primary bg-soft">
                                            <div class="row align-items-center">
                                                <div class="col-7">
                                                    <div class="text-primary p-3">
                                                        <h5 class="text-primary">Welcome Back !</h5>
                                                        <p>Koordinator Dashboard</p>
                                                    </div>
                                                </div>
                                                <?php $__currentLoopData = $koordinator_p_k_l_s; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $koor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="col-5 align-self-end">
                                                    <?php if($koor->image): ?> 
                                                    <img src="<?php echo e(asset('storage/' . $koor->image)); ?>" alt="<?php echo e($koor->nama_koor); ?>" class="img-fluid " style="width: 2.5rem; height:3rem;"> 
                                                    
                                                    <?php endif; ?>                                                
                                                </div>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                        </div>
                                        <div class="card-body pt-0">
                                            <div class="row">
                                                <div class="col-sm-6">
                                                    <?php $__currentLoopData = $koordinator_p_k_l_s; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $koor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="avatar-md profile-user-wid">
                                                        <?php if($koor->image): ?> 
                                                        <img src="<?php echo e(asset('storage/' . $koor->image)); ?>" alt="<?php echo e($koor->nama_koor); ?>" class="img-thumbnail rounded-circle " style="width: 4rem; height:4rem;"> 
                                                        
                                                        <?php endif; ?>                                                
                                                    </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <h5 class="font-size-15 text-truncate">Koordinator</h5>
                                                    <p class="text-muted mb-0 text-truncate">Koordinator PKL</p>
                                                </div>
                            
                                                <div class="col-sm-6">
                                                    <div class="pt-4">
                                                        <div class="row">
                                                            <div class="col-9">
                                                                <h5 class="font-size-15">Koordinator</h5>
                                                                <p class="text-muted mb-0"><?php echo e(Auth::guard('koordinator')->user()->department->posisi); ?></p>
                                                            </div>
                                                        </div>
                                                        <div class="mt-4">
                                                            <a href="/dataKoor" class="btn btn-primary waves-effect waves-light btn-sm">Profile <i class="mdi mdi-arrow-right ms-1"></i></a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                            <!-- end row -->
    
                        </div><!-- end row -->
                            
                        </div>
                            <!-- </div> -->
                        <!-- end page title -->

                        <footer class="footer">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-sm-6">
                                        PT.Era Solution
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="text-sm-end d-none d-sm-block">
                                            Design & Develop by SMKN 9 BEKASI
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </footer>
            </div>
            <!-- end main content-->

        </div>
        <!-- END layout-wrapper --><?php /**PATH C:\laragon\www\pendaftaranPKL3\resources\views/koorPKL/dashboard/content.blade.php ENDPATH**/ ?>