<?php echo $__env->make('siswa.statusPrakerin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;

            <!-- ============================================================== -->
            <!-- Start right Content here -->
            <!-- ============================================================== -->
            <div class="main-content">
                

                <div class="row justify-content-center" style="position: relative; bottom:2rem; right: 5rem;">
                    <div class="col-lg-8 col-md-10 col-sm-12">
                    <div class="card o-hidden border-dark shadow-lg">
                        <div class="card-body p-0">
                            <!-- Nested Row within Card Body -->
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="p-5">
                                        <div class="text-center mb-2">
                                            <h1 class="h4 mb-5 pt-4 text-xl font-semibold">Daftar Prakerin</h1>
                                        </div>
                                        <form action="/pendaftaran" method="POST" enctype="multipart/form-data">
                                            <?php echo csrf_field(); ?>
                                            <div>
                                                <div class="mb-3 row">
                                                    <label for="nama" class="col-md-2 col-form-label">Nama</label>
                                                    <div class="col-md-10">
                                                        <input class="form-control <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" placeholder="Masukkan Nama" name="nama" autofocus required>
                                                    </div>
                                                </div>
                                                <div class="mb-3 row">
                                                    <label for="username" class="col-md-2 col-form-label">Username</label>
                                                    <div class="col-md-10">
                                                        <input type="text" class="form-control <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="username" placeholder="Masukkan Username" required>
                                                    </div>
                                                </div>
                                                <div class="mb-3 row">
                                                    <label for="nama_sekolah" class="col-md-2 col-form-label">Nama Sekolah</label>
                                                    <div class="col-md-10">
                                                        <input class="form-control <?php $__errorArgs = ['nama_sekolah'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="nama_sekolah" placeholder="Masukkan Nama Sekolah">
                                                    </div>
                                                </div>
                                                <div class="mb-3 row">
                                                    <label for="email" class="col-md-2 col-form-label">E-Mail</label>
                                                    <div class="col-md-10">
                                                        <input type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required parsley-type="email" placeholder="Masukkan Email" name="email" required/>
                                                    </div>
                                                </div>
                                                <div class="mb-3 row">
                                                        <label for="password" class="col-md-2 col-form-label">Password</label>
                                                    <div class="col-md-10">
                                                        <input type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="password" name="password" placeholder="Masukkan password" required>
                                                    </div>
                                                </div>
                                                <div class="mb-3 row">
                                                    <label for="nama_pembimbing" class="col-md-2 col-form-label">Nama Pembimbing</label>
                                                    <div class="col-md-10">
                                                        <input class="form-control <?php $__errorArgs = ['nama_pembimbing'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" placeholder="Masukkan Nama Pembimbing" name="nama_pembimbing">
                                                    </div>
                                                </div>
                                                <div class="mb-3 row">
                                                    <label for="kelas" class="col-md-2 col-form-label">Kelas</label>
                                                    <div class="col-md-10">
                                                        <input class="form-control <?php $__errorArgs = ['kelas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="number" placeholder="Masukkan Kelas" name="kelas">
                                                    </div>
                                                </div>
                                                <div class="mb-3 row">
                                                    <label for="jurusan" class="col-md-2 col-form-label">Jurusan</label>
                                                    <div class="col-md-10">
                                                        <input class="form-control <?php $__errorArgs = ['jurusan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" placeholder="Masukkan Jurusan" name="jurusan">
                                                    </div>
                                                </div>
                                                <div class="mb-3 row">
                                                    <label for="nomor_telepon" class="col-md-2 col-form-label">No.Telp</label>
                                                    <div class="col-md-10">
                                                        <input class="form-control <?php $__errorArgs = ['nomor_telepon'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="number" placeholder="+627-0542-999" name="nomor_telepon">
                                                    </div>
                                                </div>                                                    
                                                <hr style="border: 1px solid rgba(0, 0, 0, 0.066);">
                                            <div>
                                                <div class="form-group mb-3 row">
                                                    <label for="tanggal_lahir" class="col-md-2 col-form-label">Kelahiran</label>
                                                    <div class="col-md-10">
                                                        <input class="form-control <?php $__errorArgs = ['tanggal_lahir'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="date" name="tanggal_lahir">
                                                    </div>
                                                </div>
                                                <div class="form-group mb-3 row">
                                                    <label for="jenis_kelamin" class="col-md-2 col-form-label">Jenis Kelamin</label>
                                                    <div class="col-md-10">
                                                        <select class="form-select" name="jenis_kelamin">
                                                            <option selected hidden disabled>Pilih Jenis Kelamin</option>
                                                            <option value="L">Laki-Laki</option>
                                                            <option value="P">Perempuan</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="form-group mb-3 row">
                                                    <label for="alamat" class="col-sm-2 col-form-label">Alamat</label>
                                                    <div class="col-md-10">
                                                        <textarea class="form-control <?php $__errorArgs = ['alamat'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="textarea" placeholder="Masukkan Alamat" name="alamat"></textarea>
                                                    </div>
                                                </div>
                                            </div>                            
                                            <div class="form-group mb-3 row">
                                                <label for="department_id" class="col-md-2 col-form-label"> Posisi</label>
                                                <div class="col-md-10">
                                                        <select class="form-select" name="department_id">
                                                            <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $department): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <?php if(old('department_id') == $department->id): ?>
                                                                    <option value="<?php echo e($department->id); ?>" selected><?php echo e($department->posisi); ?></option>
                                                                <?php else: ?>
                                                                    <option value="<?php echo e($department->id); ?>"><?php echo e($department->posisi); ?></option>
                                                                <?php endif; ?>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </select>
                                                </div>
                                            </div>
                                            <div class="form-group mb-3 row">
                                                <label for="tanggal_bergabung" class="col-md-2 col-form-label">Tanggal Bergabung</label>
                                                <div class="col-md-10">
                                                    <input class="form-control <?php $__errorArgs = ['tanggal_bergabung'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="date" name="tanggal_bergabung">
                                                </div>
                                            </div>
                                            
                                                <div class="form-group mb-3 row">
                                                    <label for="image" class="col-md-2 col-form-label">Gambar</label>
                                                    <div class="col-md-10">
                                                        <input class="form-control <?php $__errorArgs = ['image'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="file" id="image" name="image" autofocus>
                                                    </div>                                              
                                                </div>
                                            </div>
                                                <div class="form-group mb-3 row">
                                                    <label for="cv" class="col-md-2 col-form-label">CV</label>
                                                    <div class="col-md-10">
                                                        <input class="form-control <?php $__errorArgs = ['cv'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="file" id="cv" name="cv" autofocus>
                                                    </div>                                              
                                                </div>
                                            </div>
                                            <button type="submit" class="btn btn-primary w-md mb-4" id="simpan">Kirim</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- end main content-->


<?php echo $__env->make('siswa.statusPrakerin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\laragon\www\pendaftaranPKLext\resources\views/siswa/pendaftaran/create.blade.php ENDPATH**/ ?>