
        <!-- JAVASCRIPT -->
        <script src="<?php echo e(asset('pkl')); ?>/assets/libs/jquery/jquery.min.js"></script>
        <script src="<?php echo e(asset('pkl')); ?>/assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
        <script src="<?php echo e(asset('pkl')); ?>/assets/libs/metismenu/metisMenu.min.js"></script>
        <script src="<?php echo e(asset('pkl')); ?>/assets/libs/simplebar/simplebar.min.js"></script>
        <script src="<?php echo e(asset('pkl')); ?>/assets/libs/node-waves/waves.min.js"></script>

        <!-- apexcharts -->
        <script src="<?php echo e(asset('pkl')); ?>/assets/libs/apexcharts/apexcharts.min.js"></script>

        <!-- dashboard init -->
        

        <!-- dashboard init 2-->
        <script src="<?php echo e(asset('pkl')); ?>/assets/js/dashboard.init.js"></script>

        <!-- App js -->
        <script src="<?php echo e(asset('pkl')); ?>/assets/js/app.js"></script>

    </body>

</html><?php /**PATH C:\laragon\www\pendaftaranPKL3\resources\views/siswa/statusPrakerin/footer.blade.php ENDPATH**/ ?>