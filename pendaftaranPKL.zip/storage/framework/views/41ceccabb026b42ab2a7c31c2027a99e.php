<?php echo $__env->make('koorPKL.dashboard.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php echo $__env->make('koorPKL.dashboard.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


            <!-- ============================================================== -->
            <!-- Start right Content here -->
            <!-- ============================================================== -->
            <div class="main-content">

                <div class="page-content">
                    <div class="container-fluid">

                        <?php if(session()->has('success')): ?>
                    <div class="fw-bold text-success text-dark p-4">
                        <div class="container">
                            <?php echo e(session('success')); ?>

                        </div>
                    </div>
                <?php endif; ?>
                        <!-- start page title -->
                        <div class="row">
                            <div class="col-12">
                                <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                                    <h4 class="mb-sm-0 font-size-18">Status Prakerin</h4>

                                    <div class="page-title-right">
                                        <ol class="breadcrumb m-0">
                                            <li class="breadcrumb-item"><a href="javascript: void(0);">Informations</a></li>
                                            <li class="breadcrumb-item active">Information</li>
                                        </ol>
                                    </div>

                                </div>
                            </div>

                            <div class="row">
                                <div class="col-12">
                                    <div class="card">
                                        <div class="card-body">
                                            
                                            <h4 class="card-title mb-0 mb-3">Status Prakerin</h4>
                                            <!-- App Search-->
                                            
                                            <div class="app-search float-end d-none d-lg-block mt-2 mb-2">
                                                <form action="/penerimaan-pkl">
                                                    <div class="input-group position-relative">
                                                        <input type="text" class="form-control" placeholder="Search.." name="search" value="<?php echo e(request('search')); ?>">
                                                        <button class="btn btn-primary" type="submit">Search</button>
                                                    </div>
                                                </form>
                                            </div>
    
                                            <table id="datatable" class="table table-bordered dt-responsive nowrap w-100" style="border-collapse: collapse; border: 1px solid #cccccc;">
                                                <thead>
                                                <tr style="background: steelblue; color: white; text-align:center;">
                                                    <th>No</th>
                                                    <th>Nama</th>
                                                    <th>Nama Sekolah</th>
                                                    <th>Kelas</th>
                                                    <th>Jurusan</th>
                                                    <th>Nama Pembimbing</th>
                                                    <th>No.Telp</th>
                                                    <th>Tanggal Bergabung</th>
                                                    <th>Posisi</th>
                                                    <th>Status</th>
                                                    <th>Aksi</th>
                                                </tr>
                                                </thead>
            
                                                <tbody>
                                                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td><?php echo e($loop->iteration); ?></td>
                                                        <td><?php echo e($user->nama); ?></td>
                                                        <td><?php echo e($user->nama_sekolah); ?></td>
                                                        <td><?php echo e($user->kelas); ?></td>
                                                        <td><?php echo e($user->jurusan); ?></td>
                                                        <td><?php echo e($user->nama_pembimbing); ?></td>
                                                        <td><?php echo e($user->nomor_telepon); ?></td>
                                                        <td><?php echo e($user->tanggal_bergabung); ?></td>
                                                        <td><?php echo e($user->department->posisi); ?></td>
                                                        <td>
                                                            <?php if($user->status == '0'): ?>
                                                                <a href="#" class="bg-warning text-light bg-status">Pending</a>
                                                            <?php elseif($user->status == 'Ditolak'): ?>
                                                                <a href="#" class="bg-danger text-white bg-status">Ditolak</a>
                                                            <?php else: ?>
                                                                <a href="#" class="bg-success text-light bg-status">Diterima</a>
                                                            <?php endif; ?>
                                                        </td>
                                                        <td>
                                                            <form class="app-search float-end d-none d-lg-block">
                                                                <?php echo csrf_field(); ?>
                                                                <div class="search-status-container">
                                                                    <div class="position-relative" style="border: none">
                                                                        <a href="javascript:void(0);" onclick="openPopup('<?php echo e($user->id); ?>')">
                                                                            <i class="mdi mdi-cog-sync icon-bell"></i>
                                                                        </a>
                                                                    </div>
                                                                </div>
                                                            </form>
                                                            <div class="popup-container" id="popup_<?php echo e($user->id); ?>" style="display: none;">
                                                                <div class="popup-content-status">
                                                                    <span class="close-button" onclick="closePopup('<?php echo e($user->id); ?>')">&times;</span>
                                                        
                                                                    <div class="col-md-6">
                                                                        <form action="/penerimaan-pkl/<?php echo e($user->id); ?>" id="form_<?php echo e($user->id); ?>" method="post" enctype="multipart/form-data" class="d-flex">
                                                                            <?php echo method_field('PUT'); ?>
                                                                            <?php echo csrf_field(); ?>
                                                                            <div class="form-group">
                                                                                <label for="status" class="pt-2">Status</label>
                                                                                <div class="d-flex">
                                                                                <div class="input-group mb-3">
                                                                                    <select name="status" class="mt-3" style="display: inline-block; height:3rem; width: 7rem !important; text-align:center;">
                                                                                        <?php if($user->status == '0'): ?>
                                                                                            <option selected value="0">Pending</option>
                                                                                            <option value="Ditolak">Ditolak</option>
                                                                                            <option value="Diterima">Diterima</option>
                                                                                        <?php elseif($user->status == 'Ditolak'): ?>
                                                                                            <option value="0">Pending</option>
                                                                                            <option selected value="Ditolak">Ditolak</option>
                                                                                            <option value="Diterima">Diterima</option>
                                                                                        <?php else: ?>
                                                                                            <option value="0">Pending</option>
                                                                                            <option value="Ditolak">Ditolak</option>
                                                                                            <option selected value="Diterima">Diterima</option>
                                                                                        <?php endif; ?>
                                                                                    </select>
                                                                                </div>
                                                                                <button type="submit" class="btn btn-primary btn-status">Simpan</button>
                                                                                </div>
                                                                            </div>
                                                                           
                                                                        </form>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            
                                                        </td>                                                        
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div> <!-- end col -->
                            </div> <!-- end row -->
                            
                        </div>
                            <!-- </div> -->
                        <!-- end page title -->

                        <footer class="footer">
                            <div class="container-fluid">
                                <div class="row">
                                    <div class="col-sm-6">
                                        PT.Era Solution
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="text-sm-end d-none d-sm-block">
                                            Design & Develop by SMKN 9 BEKASI
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </footer>
            </div>
            <!-- end main content-->

        </div>
        <!-- END layout-wrapper -->

<?php echo $__env->make('siswa.statusPrakerin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\pendaftaranPKL\resources\views/koorPKL/dataTables/dataStatusPrakerin/index.blade.php ENDPATH**/ ?>