@include('siswa.statusPrakerin.header')

@include('siswa.statusPrakerin.sidebar')

@include('siswa.statusPrakerin.content')

@include('siswa.statusPrakerin.footer')