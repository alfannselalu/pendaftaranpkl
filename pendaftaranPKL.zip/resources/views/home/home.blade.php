<body class="d-flex align-items-center">
    <div class="container text-center">
        <div class="px-3 text-dark mt-5" style="position: relative; top:5rem;">
            <h1 class="text-dark mb-3 fw-bold" style="font-family: Raleway; font-size: 3rem;">Let's Goooo</h1>
            <h2 class="text-dark mb-3 fw-bold">Selamat Datang di Program Praktek Kerja Lapangan Di Era Solution! <br>
                Jelajahi Kesempatan Menarik di Dunia Kerja Sebenarnya.</h2>
            <p class="lead">
                <a href="/cek-ketersediaan" class="btn btn-lg btn-dark me-3 me-md-5 fw-bold border-info bg-info text-dark" style="border-radius: 2rem;">Cek Ketersediaan</a>
                <a href="#" class="btn btn-lg btn-dark fw-bold border-transparent bg-transparent text-dark" style="border-radius: 2rem;">Contact Us</a>
            </p>
        </div>
    </div>
</body>
