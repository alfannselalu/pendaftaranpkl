@include('admin.dashboard.header')

@include('admin.dashboard.sidebar')

@include('admin.dashboard.content')

@include('admin.dashboard.footer')